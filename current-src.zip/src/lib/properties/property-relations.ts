import type { Property } from "@/types/maintenance";
import type { Project } from "@/types/project";
import type { MaintenanceTask, EquipmentMaintenanceSchedule } from "@/types/maintenance";
import type { MaintenanceLogEntry } from "@/lib/maintenance/maintenance-log-store";
import type { FieldPhoto } from "@/types/field-operations";

function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/\bstreet\b/g, "st")
    .replace(/[^a-z0-9]/g, "")
    .trim();
}

/**
 * Matches a Property to construction Projects. There's no explicit link
 * for most of them (only relatedProjectId, rarely set), so this compares
 * normalized text against both the project's name and its street address
 * — e.g. Property "18 Cross St" matches Project address "18 Cross Street"
 * even with the street/st spelling difference.
 */
export function getRelatedProjects(property: Property, projects: Project[]): Project[] {
  const firstSegment = property.name.split("/")[0].split("(")[0].trim();
  const propKey = normalize(firstSegment).replace(/^the/, "");
  if (!propKey) return [];

  return projects.filter((p) => {
    if (property.relatedProjectId === p.id) return true;
    const nameKey = normalize(p.projectName);
    const streetKey = normalize(p.address.street);
    return (
      nameKey.includes(propKey) ||
      propKey.includes(nameKey) ||
      streetKey.includes(propKey) ||
      propKey.includes(streetKey)
    );
  });
}

export interface MaintenanceHistory {
  tasks: MaintenanceTask[];
  schedules: EquipmentMaintenanceSchedule[];
  logEntries: MaintenanceLogEntry[];
}

function matchesProperty(property: Property, propertyId?: string, propertyName?: string): boolean {
  if (propertyId) return propertyId === property.id;
  if (propertyName) return propertyName.toLowerCase() === property.name.toLowerCase();
  return false;
}

export function getPropertyForBillingEntity(billingEntityId: string | undefined, properties: Property[]): Property | undefined {
  if (!billingEntityId) return undefined;
  return properties.find((p) => p.billingEntityId === billingEntityId);
}

/**
 * Reverse of getRelatedProjects — given a construction Project, finds its
 * matching Property and returns that property's billing entity, if any.
 * Used to auto-populate Billing Entity on Purchase Orders and Field
 * Worker Invoices from the project alone, since a property's billing
 * entity is the closest thing to a canonical "who gets billed" answer.
 */
/**
 * Given a construction Project, finds its matching Property directly —
 * used to auto-populate the Property field the moment a Project is
 * picked, across Daily Logs, Documents, Drawings, and Photos, so nobody
 * has to pick both by hand.
 */
export function getPropertyForProject(project: Project, properties: Property[]): Property | undefined {
  return properties.find((property) => getRelatedProjects(property, [project]).length > 0);
}

export function getBillingEntityIdForProject(project: Project, properties: Property[]): string | undefined {
  for (const property of properties) {
    if (getRelatedProjects(property, [project]).length > 0 && property.billingEntityId) {
      return property.billingEntityId;
    }
  }
  return undefined;
}

export function getMaintenanceHistory(
  property: Property,
  tasks: MaintenanceTask[],
  schedules: EquipmentMaintenanceSchedule[],
  logEntries: MaintenanceLogEntry[]
): MaintenanceHistory {
  return {
    tasks: tasks.filter((t) => matchesProperty(property, t.propertyId, t.propertyName)),
    schedules: schedules.filter((s) => matchesProperty(property, s.propertyId, s.propertyName)),
    logEntries: logEntries.filter((l) => matchesProperty(property, undefined, l.propertyName)),
  };
}

/**
 * Photos live in the Documents module, keyed to a construction project's
 * ID — not directly to a Property. This aggregates photos across every
 * related project so a property with multiple project phases shows all
 * of them together.
 */
export function getPropertyPhotos(relatedProjects: Project[], allPhotos: FieldPhoto[]): FieldPhoto[] {
  const projectIds = new Set(relatedProjects.map((p) => p.id));
  return allPhotos.filter((photo) => projectIds.has(photo.projectId));
}
